package com.aantoniusron.wheeldb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WheeldbApplicationTests {

	@Test
	void contextLoads() {
	}

}

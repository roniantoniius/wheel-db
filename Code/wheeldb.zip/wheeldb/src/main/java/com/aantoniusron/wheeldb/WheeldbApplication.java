package com.aantoniusron.wheeldb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WheeldbApplication {

	public static void main(String[] args) {
		SpringApplication.run(WheeldbApplication.class, args);
	}

}
